<?php
/**
 * Silence is golden.
 *
 * @package miniOrange_LDAP_AD_Integration
 */
